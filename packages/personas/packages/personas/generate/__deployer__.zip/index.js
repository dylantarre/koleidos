const OpenAI = require('openai');
const { spawn } = require('child_process');
const path = require('path');

const RANDOM_PERSONA_TEMPLATE = `Create a random user persona with diverse interests and backgrounds w

Note:
1. The persona should include the following sections:
   - Name: The persona's name
   - Demographics: Age, gender, occupation, education, and location (make these diverse and random)
   - Goals: General life or career goals
   - Frustrations: General online frustrations
   - Behaviors: General online behaviors
   - Motivations: What generally motivates them in life
   - Technological Proficiency: Their comfort level with technology
   - Preferred Channels: How they generally interact with websites
2. Make the persona realistic but not necessarily interested in this type of website
3. Return the response in JSON format with the same structure as before`;

const POTENTIAL_USER_TEMPLATE = `Create a detailed UX persona who would be a potential user of this website: {url}

Note:
1. The persona should include the following sections:
   - Name: The persona's name
   - Demographics: Age, gender, occupation, education, and location
   - Goals: What the persona aims to achieve with this website
   - Frustrations: Pain points and challenges they might face with this website
   - Behaviors: Typical actions and habits when using websites like this
   - Motivations: What drives them to use this website
   - Technological Proficiency: Their comfort level with technology
   - Preferred Channels: How they prefer to interact with websites
2. Make the persona realistic and specific to this type of website
3. Return the response in JSON format with the following structure:
{
  "name": string,
  "avatar": string (use an Unsplash URL),
  "type": string (their primary user type),
  "description": string (a one-line summary),
  "demographics": {
    "age": number,
    "gender": string,
    "occupation": string,
    "education": string,
    "location": string
  },
  "goals": string[],
  "frustrations": string[],
  "behaviors": string[],
  "motivations": string[],
  "techProficiency": string,
  "preferredChannels": string[]
}`;

async function generatePersona(url, openai, type = 'potential') {
  try {
    // Generate persona directly with OpenAI instead of using dataset
    const template = type === 'random' ? RANDOM_PERSONA_TEMPLATE : POTENTIAL_USER_TEMPLATE.replace("{url}", url);
    
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a UX research expert who creates detailed user personas."
        },
        {
          role: "user",
          content: template
        }
      ]
    });

    try {
      const persona = JSON.parse(completion.choices[0].message.content);
      return {
        ...persona,
        id: Date.now().toString() + Math.random(),
        status: 'idle',
        isLocked: false,
        messages: []
      };
    } catch (parseError) {
      console.error('Error parsing OpenAI response:', parseError);
      throw new Error('Invalid response format from OpenAI');
    }
  } catch (error) {
    console.error('Error in generatePersona:', error);
    throw error;
  }
}

async function generatePersonasFromHub(url, count, personaType) {
  return new Promise((resolve, reject) => {
    const pythonScript = path.join(__dirname, 'persona_hub.py');
    const python = spawn('python3', [pythonScript, url, count.toString(), personaType]);
    
    let dataString = '';
    
    python.stdout.on('data', (data) => {
      dataString += data.toString();
    });
    
    python.stderr.on('data', (data) => {
      console.error(`Python Error: ${data}`);
    });
    
    python.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Python process exited with code ${code}`));
        return;
      }
      
      try {
        const personas = JSON.parse(dataString);
        if (personas.error) {
          reject(new Error(personas.error));
          return;
        }
        resolve(personas);
      } catch (error) {
        reject(error);
      }
    });
  });
}

module.exports.main = async (args) => {
  try {
    console.log('Received args:', args);

    // Handle both direct invocation and HTTP request
    const params = args.__ow_body ? JSON.parse(args.__ow_body) : args;
    console.log('Parsed params:', params);

    if (!params || !params.url) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: { error: 'URL is required' }
      };
    }

    const { url, count = 5, personaType = 'potential' } = params;

    if (!process.env.OPENAI_API_KEY) {
      return {
        statusCode: 500,
        headers: { 'Content-Type': 'application/json' },
        body: { error: 'OpenAI API key is not configured' }
      };
    }

    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });

    try {
      // Generate personas directly with OpenAI
      const personas = await Promise.all(
        Array(count).fill(null).map(() => generatePersona(url, openai, personaType))
      );

      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: personas
      };
    } catch (error) {
      console.error('Error generating personas:', error);
      return {
        statusCode: 500,
        headers: { 'Content-Type': 'application/json' },
        body: { 
          error: 'Failed to generate personas', 
          details: error.message,
          stack: error.stack
        }
      };
    }
  } catch (error) {
    console.error('Error in main function:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: { 
        error: 'Failed to process request', 
        details: error.message,
        stack: error.stack
      }
    };
  }
}; 