import json
import random
import os
import sys
from typing import Dict, List, Optional
import openai

RANDOM_PERSONA_TEMPLATE = """Create a random user persona with diverse interests and backgrounds.
The persona should be realistic but not necessarily interested in this type of website.
Return the response in JSON format with the following structure:
{
  "name": string,
  "avatar": string (use an Unsplash URL),
  "type": string (their primary user type),
  "description": string (a one-line summary),
  "demographics": {
    "age": number,
    "gender": string,
    "occupation": string,
    "education": string,
    "location": string
  },
  "goals": string[],
  "frustrations": string[],
  "behaviors": string[],
  "motivations": string[],
  "techProficiency": string,
  "preferredChannels": string[]
}"""

POTENTIAL_USER_TEMPLATE = """Create a detailed UX persona who would be a potential user of this website: {url}
The persona should be realistic and specific to this type of website.
Return the response in JSON format with the following structure:
{
  "name": string,
  "avatar": string (use an Unsplash URL),
  "type": string (their primary user type),
  "description": string (a one-line summary),
  "demographics": {
    "age": number,
    "gender": string,
    "occupation": string,
    "education": string,
    "location": string
  },
  "goals": string[],
  "frustrations": string[],
  "behaviors": string[],
  "motivations": string[],
  "techProficiency": string,
  "preferredChannels": string[]
}"""

def generate_persona(url: str, persona_type: str = 'potential') -> Dict:
    """Generate a persona using OpenAI."""
    try:
        openai.api_key = os.getenv('OPENAI_API_KEY')
        if not openai.api_key:
            raise ValueError("OpenAI API key is not configured")

        template = RANDOM_PERSONA_TEMPLATE if persona_type == 'random' else POTENTIAL_USER_TEMPLATE.replace("{url}", url)
        
        completion = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role": "system",
                    "content": "You are a UX research expert who creates detailed user personas."
                },
                {
                    "role": "user",
                    "content": template
                }
            ]
        )
        
        persona = json.loads(completion.choices[0].message.content)
        return {
            **persona,
            'id': f"{random.randint(1000, 9999)}-{random.randint(1000, 9999)}",
            'status': 'idle',
            'isLocked': False,
            'messages': []
        }
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON response from OpenAI: {str(e)}")
    except Exception as e:
        raise Exception(f"Error generating persona: {str(e)}")

def generate_personas(url: str, count: int = 5, persona_type: str = 'potential') -> List[Dict]:
    """Generate multiple personas."""
    try:
        personas = []
        for _ in range(count):
            persona = generate_persona(url, persona_type)
            personas.append(persona)
        return personas
    except Exception as e:
        raise Exception(f"Error generating personas: {str(e)}")

if __name__ == "__main__":
    try:
        # Get arguments from command line
        if len(sys.argv) < 4:
            print(json.dumps({
                'error': 'Missing arguments. Required: url count persona_type'
            }))
            sys.exit(1)
            
        test_url = sys.argv[1]
        count = int(sys.argv[2])
        persona_type = sys.argv[3]
        
        try:
            personas = generate_personas(test_url, count, persona_type)
            print(json.dumps(personas))
        except Exception as e:
            print(json.dumps({
                'error': str(e)
            }))
            sys.exit(1)
    except Exception as e:
        print(json.dumps({
            'error': str(e)
        }))
        sys.exit(1) 